
hkx2dae converts Havok HKX files to COLLADA Physics .dae files. So Havok tools can be used with any COLLADA Physics enabled application, such as the Bullet physics engine.
Use the patch in combination with the free Havok 5.5 version to add COLLADA Physics export to the Havok SimpleLoad serialization sample (hk550\Demo\Demos\Common\Api\Serialize\SimpleLoad).

For precompiled binary and further information, visit:
http://www.bulletphysics.com/Bullet/phpBB3/viewtopic.php?f=12&t=2218
